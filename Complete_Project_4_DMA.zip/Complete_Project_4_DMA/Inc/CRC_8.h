/*
 * CRC_8.h
 *
 *  Created on: 08.02.2020
 *      Author: �ukasz
 */

#ifndef CRC_8_H_
#define CRC_8_H_

char CRC8(const char *data,int length)
{
   unsigned char crc = 0x00;
   unsigned char extract;
   unsigned char sum;
   int i;
   unsigned char tempI;

   for(i=0;i<length;i++)
   {
      extract = *data;
      for (tempI = 8; tempI; tempI--)
      {
         sum = (crc ^ extract) & 0x01;
         crc >>= 1;
         if (sum)
            crc ^= 0x8C;
         extract >>= 1;
      }
      data++;
   }
   return crc;
}


#endif /* CRC_8_H_ */


