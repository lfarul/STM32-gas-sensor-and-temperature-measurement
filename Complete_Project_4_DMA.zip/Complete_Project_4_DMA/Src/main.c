/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2020 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f0xx_hal.h"
#include "stdarg.h"
#include "string.h"
#include "i2c-lcd.h"
#include <stdio.h>
#include "CRC_8.h"

#define	START_OF_FRAME	';'
#define	END_OF_FRAME	';'

#define   GOOD_CHAR      '?'
#define   BETTER_CHAR    '!'


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// Temperature - dokumentacja
uint16_t const *TS_CAL1 = (uint16_t*) 0x1FFFF7B8;
uint16_t const *TS_CAL2 = (uint16_t*) 0x1FFFF7C2;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;
DMA_HandleTypeDef hdma_adc;
CRC_HandleTypeDef hcrc;
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

float Temperature = 0.0;
float HalfTemperature = 0.0;
float avgGas = 0.0;
float avgHalfGas = 0.0;

unsigned char crc = 0x00;
unsigned char crc_rec;
unsigned char crc_calc;

// bufor do przechowywania wyników konwersji przetwornika ADC z DMA

uint16_t ADC_BUF[250][2];

//uint16_t ADC_BUF[5];

uint8_t BUFF_SIZE = 255;

// bufor odbiorczy oraz nadawczy o rozmiarze 255 bajtów
volatile char Buff_Rx[255];
volatile char Buff_Tx[255];


volatile uint8_t Busy_Tx = 0;
volatile uint8_t Empty_Tx = 0;
volatile uint8_t Busy_Rx = 0;
volatile uint8_t Empty_Rx = 0;

char Bx[255];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC_Init(void);
static void MX_I2C1_Init(void);
static void MX_CRC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// format to wskaźnik do obiektu typu char
void USART_fsend(char* format, ...) {

	char tmp_rs[128];
	int i;
	__IO int idx;
	va_list valist;
	va_start(valist, format);

	vsprintf(tmp_rs, format, valist);
	va_end(valist);
	idx = Empty_Tx;
	for (i = 0; i < strlen(tmp_rs); i++) {
		Buff_Tx[idx] = tmp_rs[i];
		idx++;
		if (idx >= BUFF_SIZE)
			idx = 0;
	}
	__disable_irq();
	if ((Empty_Tx == Busy_Tx)
			&& (__HAL_UART_GET_FLAG(&huart2,UART_FLAG_TXE) == SET)) {

		Empty_Tx = idx;
		uint8_t tmp = Buff_Tx[Busy_Tx];
		Busy_Tx++;
		if (Busy_Tx >= BUFF_SIZE)
			Busy_Tx = 0;
		HAL_UART_Transmit_IT(&huart2, &tmp, 1);

	} else {
		Empty_Tx = idx;
	}
	__enable_irq();
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	if(huart == &huart2)
	{
		Empty_Rx++;
		if (Empty_Rx >= BUFF_SIZE)
					Empty_Rx = 0;
		HAL_UART_Receive_IT(&huart2,(uint8_t *)&Buff_Rx[Empty_Rx],1);
	}
}


void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
	if (huart == &huart2) {

		if (Empty_Tx != Busy_Tx) {
			uint8_t tmp = Buff_Tx[Busy_Tx];
			Busy_Tx++;
			if (Busy_Tx >= BUFF_SIZE)
				Busy_Tx = 0;
			HAL_UART_Transmit_IT(&huart2, &tmp, 1);
		}
	}
}

uint8_t czyNiePustyRx() {
	if (Empty_Rx == Busy_Rx) {
		return 0;
	} else {
		return 1;
	}
}

uint8_t USART_getchar() {

	uint8_t tmp;

	if (Empty_Rx != Busy_Rx) {

		tmp = Buff_Rx[Busy_Rx];
		Busy_Rx++;
		if (Busy_Rx >= BUFF_SIZE)
			Busy_Rx = 0;
		return tmp;
	} else
		return 0;
}

// Ramka
uint8_t USART_getline(char * buff) {

	static uint8_t bf[129];
	static uint8_t idx = 0;
	static int sof_received = 0;
	int i;
	uint8_t ret;


	while (czyNiePustyRx()) {

			bf[idx] = USART_getchar();

			if (bf[idx] == 0x3B) {
	            if(sof_received == 1) {
	                bf[idx] = 0;
	                for (i = 0; i <= idx; i++) {
	                    buff[i] = bf[i];
	                }
	                ret = idx;
	                idx = 0;

	                sof_received = 0;

	                return ret;
	            }
	            else {
	                sof_received = 1;
	            }
			}
			else if (sof_received == 1) {
				idx++;
				if (idx >= 129)
					idx = 0;
			}
		}
		return 0;
	}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */



  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_ADC_Init();
  MX_I2C1_Init();
  MX_CRC_Init();
  /* USER CODE BEGIN 2 */



  HAL_UART_Receive_IT(&huart2, (uint8_t *) &Buff_Rx[0], 1);
  int len=0;


  HAL_ADC_Start_DMA(&hadc,(uint32_t*)&ADC_BUF,500);


  lcd_init();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if((len = USART_getline(Bx)) > 0){

		  lcd_clear();
		  lcd_put_cur(0,0);

		  if(len > 129){
			  USART_fsend("Za dlugi payload\r");
			  lcd_send_string ("Za dlugi payload");
			  continue;
		  }

		  unsigned char crc_rec = Bx[len-1]; // CRC pobrane z ramki

		  char cmd_buff[128];				// bufor na komende
		  for(unsigned int i = 0; i < len-1; ++i)
			  cmd_buff[i] = Bx[i];
		  cmd_buff [len-1] = 0; // kończe komendę 0, indeksuje bufor cmd_buff i na pozycji len-1 czyli w miejscu crc podaje 0

		  unsigned cmd_buff_length = strlen(cmd_buff);

		  char temp_cmd_buff[256];

		  temp_cmd_buff[0] = '\0';
		  strcat(temp_cmd_buff, cmd_buff);


		  // składam ramkę którą otrzymałem z PC
		  char frame_pc[256];

		  frame_pc[0] = START_OF_FRAME;
		  frame_pc[1] = '\0';
		  strcat(frame_pc, cmd_buff);

		  frame_pc[cmd_buff_length+1] = crc_rec;
		  frame_pc[cmd_buff_length+2] = END_OF_FRAME;
		  frame_pc[cmd_buff_length+3] = '\0';


		  // odkodowanie ramki

		    char decod_frame[256];
		    char decod_cmd[256];
		    char temp_buff[128];
		    temp_buff[0] = '\0';
		    char* search_strchr;
		    char ch = '?';
		    int i=0;


		  // Przypadek 1 - komenda zakodowana '?' => '!?'  te?mp => te!?mp
		  // Odkodowanie komendy '!?' => '?' te!?mp => te?mp

		    // dekoduje komendę

		  if(strchr(cmd_buff, BETTER_CHAR) != NULL){ // jeżeli w buforze / komendzie znajduje się '!'

			  search_strchr = strchr(cmd_buff, ch); // to zwracam wskaźnik na '?'

		       while(cmd_buff[i] != BETTER_CHAR){ // tak długo jak ity element w buforze jest różny od '!'

		               temp_buff[i] = cmd_buff[i]; // kopiuj do bufora
		               temp_buff[i+1] = '\0'; // na końcu null
		       i++;
		       }

		       // składam zdekodowaną komendę
		       decod_cmd[0] = '\0';
		       strcat(decod_cmd,temp_buff);
		       strcat(decod_cmd,search_strchr);


		       unsigned decod_cmd_length = strlen(decod_cmd);

		       // liczę crc dla zdekodowanej komendy
		       unsigned char crc_calc = CRC8(decod_cmd,decod_cmd_length);

		       USART_fsend("Zakodowana ramka przeslana z PC: %s\r", frame_pc);
		       USART_fsend("Otrzymana komenda z PC: %s\r", cmd_buff);
		       USART_fsend("Otrzymane CRC z PC: 0x%x\r", crc_rec);
		       USART_fsend("--------------------------------------------\r");
		       USART_fsend("Komenda po zdekodowaniu przez MCU: %s\r", decod_cmd);
		       USART_fsend("Policzone CRC przez MCU: 0x%x\r", crc_calc);

		       // Składam ramkę z zdekodowaną komendą
		       decod_frame[0] = START_OF_FRAME;
		       decod_frame[1] = '\0'; //ustawiam sobie terminating string przed łączeniem
		       strcat(decod_frame,decod_cmd);

		       //unsigned decod_frame_length = strlen(decod_frame);

		       decod_frame[decod_cmd_length+1] = crc_calc;
		       decod_frame[decod_cmd_length+2] = END_OF_FRAME;
		       decod_frame[decod_cmd_length+3] = '\0';

		       if(crc_rec == crc_calc){
		 		  if (strcmp(decod_cmd,"te?mp")==0){
		 			  USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		 			  lcd_send_string ("cmd:");
		 			  lcd_put_cur(0,5);
		 			  lcd_send_string (decod_cmd);
		 		  }

		 		  else if (strcmp(decod_cmd,"?temp")==0){
		 			  USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		 			  lcd_send_string ("cmd:");
		 			  lcd_put_cur(0,5);
		 			  lcd_send_string (decod_cmd);
		 		  }

		 		  else if (strcmp(decod_cmd,"temp?")==0){
		 			  USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		 			  lcd_send_string ("cmd:");
		 			  lcd_put_cur(0,5);
		 			  lcd_send_string (decod_cmd);
		 		  }

		 		  else {
					  USART_fsend("Zle CRC\r");
					  lcd_send_string ("Zle CRC");
		 		  }
		       }
		  }

		  // Przypadek 2 - komenda zakodowana ';' => '?'  te;mp => te?mp
		  // Odkodowanie komendy '?' => ';' te?mp => te;mp

		  // dekoduje komendę
		  else if (strchr(cmd_buff, GOOD_CHAR) != NULL){

			  for(i=0; i<cmd_buff_length; i++){
				  if(cmd_buff[i]== GOOD_CHAR){
					  cmd_buff[i] = START_OF_FRAME;
				  }
			  }

			  // składam zdekodowaną komendę
		       decod_cmd[0] = '\0';
		       strcat(decod_cmd, cmd_buff);

		       unsigned decod_cmd_length = strlen(decod_cmd);

		       // liczę crc dla zdekodowanej komendy
		       unsigned char crc_calc = CRC8(decod_cmd, decod_cmd_length);


		       // Składam ramkę z zdekodowaną komendą
		       decod_frame[0] = START_OF_FRAME;
		       decod_frame[1] = '\0';
		       strcat(decod_frame, decod_cmd);

		       decod_frame[decod_cmd_length+1] = crc_calc;
		       decod_frame[decod_cmd_length+2] = END_OF_FRAME;
		       decod_frame[decod_cmd_length+3] = '\0';

		       USART_fsend("Zakodowana ramka przeslana z PC: %s\r", frame_pc);
		       USART_fsend("Otrzymana komenda z PC: %s\r", temp_cmd_buff);
		       USART_fsend("Otrzymane CRC z PC: 0x%x\r", crc_rec);
		       USART_fsend("--------------------------------------------\r");
		       USART_fsend("Komenda po zdekodowaniu przez MCU: %s\r", decod_cmd);
		       USART_fsend("Policzone CRC przez MCU: 0x%x\r", crc_calc);

		       if(crc_rec == crc_calc){

		    	   if (strcmp(decod_cmd,"te;mp")==0){

		    		   USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		    		   lcd_send_string ("cmd:");
		    		   lcd_put_cur(0,5);
		    		   lcd_send_string (decod_cmd);
		    	   }

		    	   else if (strcmp(decod_cmd,";temp")==0){

		    		   USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		    		   lcd_send_string ("cmd:");
		    		   lcd_put_cur(0,5);
		    		   lcd_send_string (decod_cmd);
		    	   }

		    	   else if (strcmp(decod_cmd,"t;emp")==0){

		    		   USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		    		   lcd_send_string ("cmd:");
		    		   lcd_put_cur(0,5);
		    		   lcd_send_string (decod_cmd);
		    	   }

		    	   else if (strcmp(decod_cmd,"tem;p")==0){

		    		   USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		    		   lcd_send_string ("cmd:");
		    		   lcd_put_cur(0,5);
		    		   lcd_send_string (decod_cmd);
		    	   }

		    	   else if (strcmp(decod_cmd,"temp;")==0){

		    		   USART_fsend("Odkodowana ramka przez MCU: %s\r", decod_frame);
		    		   lcd_send_string ("cmd:");
		    		   lcd_put_cur(0,5);
		    		   lcd_send_string (decod_cmd);
		    	   }

		    	   else {

		    		   USART_fsend("Zla komenda: %s\r", decod_cmd);
		    		   lcd_send_string ("Zla komenda");
		    	   }
		       }

		       else {

	    		   USART_fsend("Zle CRC\r");
	    		   lcd_send_string ("Zle CRC");
		       }
		  }

		  // 3 przypadek - bez kodowania - brak w komendzie znaków specjalnych ';' '?' oraz '!?'

		  else{

		       // składam zdekodowaną komendę
			  decod_cmd[0] = '\0';
			  strcat(decod_cmd,cmd_buff);

			  unsigned decod_cmd_length = strlen(decod_cmd);

			  unsigned char crc_calc = CRC8(decod_cmd, decod_cmd_length);


			  // Składam ramkę
		      decod_frame[0] = START_OF_FRAME;
		      decod_frame[1] = '\0';

		      strcat(decod_frame, decod_cmd);

		      decod_frame[decod_cmd_length+1] = crc_calc;
		      decod_frame[decod_cmd_length+2] = END_OF_FRAME;
		      decod_frame[decod_cmd_length+3] = '\0';

		      USART_fsend("Otrzymana ramka z PC: %s\r", frame_pc);
		      USART_fsend("Otrzymana komenda z PC: %s\r", cmd_buff);
		      USART_fsend("Otrzymane CRC z PC: 0x%x\r", crc_rec);
		      USART_fsend("--------------------------------------------\r");

		      USART_fsend("Komenda po zdekodowaniu przez MCU: %s\r", decod_cmd);
		      USART_fsend("Policzone CRC przez MCU: 0x%x\r", crc_calc);

		      if(crc_rec == crc_calc){

				  if (strcmp(decod_cmd, "temp")==0){

					  USART_fsend("Otrzymana ramka: %s\r", decod_frame);
					  lcd_send_string ("Temp:");
					  lcd_put_cur(0,6);
					  lcd_send_floatData(Temperature);
				  }

				  else if (strcmp(decod_cmd, "htemp")==0){

					  USART_fsend("Otrzymana ramka: %s\r", decod_frame);
					  lcd_send_string ("Half_T:");
					  lcd_put_cur(0,8);
					  lcd_send_floatData(HalfTemperature);
				  }

				  else if (strcmp(decod_cmd,"gaz")==0){

					  USART_fsend("Otrzymana ramka: %s\r", decod_frame);
					  lcd_send_string ("Gaz:");
					  lcd_put_cur(0,6);
					  lcd_send_floatData(avgGas);
				  }

				  else if (strcmp(decod_cmd,"hgaz")==0){

					  USART_fsend("Otrzymana ramka: %s\r", decod_frame);
					  lcd_send_string ("Half_G:");
					  lcd_put_cur(0,8);
					  lcd_send_floatData(avgHalfGas);
				  }

				  else {

					  USART_fsend("Zla komenda: %s\r", decod_cmd);
					  lcd_send_string ("Zla komenda");
				  }
		      }

		      else {

		    	  USART_fsend("Zle CRC\r");
		    	  lcd_send_string ("Zle CRC");
		      }
		  }
	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSI14
                              |RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI48;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */
  /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
  */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = ENABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = ENABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }
  /**Configure for the selected ADC regular channel to be converted. 
  */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /**Configure for the selected ADC regular channel to be converted. 
  */
  sConfig.Channel = ADC_CHANNEL_TEMPSENSOR;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_ENABLE;
  hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
  hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
  hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
  hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_CRCEx_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x2000090E;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /**Configure Analogue filter 
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /**Configure Digital filter 
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */


 void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc){

	 //__NOP();

	uint32_t sumHalfGas = 0;
	uint32_t sumHalfTemp = 0;
	float avgHalfTemp = 0.0;

	 for(int i=0; i<125; i++){

		 sumHalfGas += ADC_BUF[i][0];

		 sumHalfTemp += ADC_BUF[i][1];

		 }

	 avgHalfGas = sumHalfGas / 125;
	 avgHalfTemp = sumHalfTemp / 125;

	 HalfTemperature = (float)(110.0-30.0)/(float)(*TS_CAL2-*TS_CAL1)*(float)(avgHalfTemp - *TS_CAL1)+30.0;

	 }


 void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc){

	 //__NOP();

	 uint32_t sumGas = 0;
	 uint32_t sumTemp = 0;
	 float avgTemp = 0.0;


	 for(int i=125; i<250; i++){

			 sumGas += ADC_BUF[i][0];
			 sumTemp += ADC_BUF[i][1];
		 }

	 avgGas = sumGas / 125;
	 avgTemp = sumTemp / 125;

	 Temperature = (float)(110.0-30.0)/(float)(*TS_CAL2-*TS_CAL1)*(float)(avgTemp - *TS_CAL1)+30.0;

	 }


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
